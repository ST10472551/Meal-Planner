package vcmsa.ci.mealplan

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

impor
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val timeOfDayInput: EditText = findViewById(R.id.timeOfDayEditText)
        val showSuggestionButton: Button = findViewById(R.id.showSuggestionButton)
        val suggestionTextView: TextView = findViewById(R.id.suggestionTextView)
        val resetButton: Button = findViewById(R.id.resetButton)

        showSuggestionButton.setOnClickListener {
            val timeOfDay = timeOfDayInput.text.toString().trim()
            val suggestion = getMealSuggestion(timeOfDay)
            suggestionTextView.text = suggestion
        }

        resetButton.setOnClickListener {
            timeOfDayInput.text.clear()
            suggestionTextView.text = ""
        }
    }

    private fun getMealSuggestion(timeOfDay: String): String {
        return when (timeOfDay.toLowerCase()) {
            "morning" -> "Breakfast: Eggs"
            "mid-morning" -> "Snack: Fruit"
            "noon" -> "Lunch: Sandwich"
            "mid-afternoon" -> "Snack: Cake"
            "dinner" -> "Dinner: Pasta"
            "after-dinner" -> "Dessert: Ice Cream"
            else -> "Please enter a valid time of day (morning, mid-morning, noon, mid-afternoon, dinner, after-dinner)."
        }
    }
}

















